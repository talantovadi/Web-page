let changePhoto = document.querySelector("img");
let count = 0;
changePhoto.onclick = () => {
    if (count % 2 === 0) {
        changePhoto.setAttribute("src", "imgs/logo.jpg");
    }
    else {
        changePhoto.setAttribute ("src", "imgs/2ndphotoo.jpg");
    }
    count++;
};

const button = document.getElementById('button');

button.addEventListener('click', () => {
    var name =  prompt("Please, enter your name:");
    if (name != null){
        var myHeading = document.querySelector("h1");
    myHeading.textContent = `Welcome, ${name}!`;
    button.setAttribute("style", "display: none;");
    }
});